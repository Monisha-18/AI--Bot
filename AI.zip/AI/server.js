const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// API Constants
const GEMINI_API_URL = "https://api.gemini.example.com"; // Replace with actual API URL
const API_KEY = process.env.GEMINI_API_KEY;

// Fetch question based on domain
app.post('/api/get-question', async (req, res) => {
    const { domain } = req.body;
    try {
        const response = await axios.post(`${GEMINI_API_URL}/generate_question`, {
            domain,
        }, {
            headers: { Authorization: `Bearer ${API_KEY}` }
        });
        res.json({ question: response.data.question });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error fetching question' });
    }
});

// Grade user answer
app.post('/api/grade-answer', async (req, res) => {
    const { domain, question, userAnswer } = req.body;
    try {
        const response = await axios.post(`${GEMINI_API_URL}/grade_answer`, {
            domain,
            question,
            user_answer: userAnswer,
        }, {
            headers: { Authorization: `Bearer ${API_KEY}` }
        });
        const { score, feedback } = response.data;
        res.json({ score, feedback });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error grading answer' });
    }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
