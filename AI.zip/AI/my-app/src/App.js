import React, { useState } from 'react';
import axios from 'axios';

const App = () => {
  const [domain, setDomain] = useState('');
  const [question, setQuestion] = useState('');
  const [userAnswer, setUserAnswer] = useState('');
  const [score, setScore] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Fetch question from backend
  const fetchQuestion = async () => {
    if (!domain.trim()) {
      setError('Domain is required to generate a question.');
      return;
    }

    setError(''); // Reset any previous errors
    try {
      setLoading(true);
      const response = await axios.post('http://localhost:5000/api/get-question', { domain });
      if (response.data.question) {
        setQuestion(response.data.question);
        setUserAnswer(''); // Clear previous answer
        setScore(null); // Reset score
        setFeedback(''); // Reset feedback
      } else {
        setError('No question received from the server.');
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching question:', error);
      setError('Failed to generate question. Please try again.');
      setLoading(false);
    }
  };

  // Submit answer for grading
  const submitAnswer = async () => {
    if (!userAnswer.trim()) {
      setError('Please provide an answer before submitting.');
      return;
    }

    setError(''); // Reset any previous errors
    try {
      setLoading(true);
      const response = await axios.post('http://localhost:5000/api/grade-answer', {
        domain,
        question,
        userAnswer,
      });

      if (response.data.score !== undefined) {
        setScore(response.data.score);
        setFeedback(response.data.feedback || '');
      } else {
        setError('No score received from the server.');
      }
      setLoading(false);
    } catch (error) {
      console.error('Error grading answer:', error);
      setError('Failed to submit your answer. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <h1>AI Interview Question Generator</h1>

      <div>
        <label>Enter Domain:</label>
        <input
          type="text"
          value={domain}
          onChange={(e) => setDomain(e.target.value)}
          disabled={loading}
        />
        <button onClick={fetchQuestion} disabled={loading}>
          {loading ? 'Loading...' : 'Generate Question'}
        </button>
      </div>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {question && (
        <div>
          <h2>Question: {question}</h2>
          <label>Enter Your Answer:</label>
          <textarea
            value={userAnswer}
            onChange={(e) => setUserAnswer(e.target.value)}
            disabled={loading}
          />
          <button onClick={submitAnswer} disabled={loading || !userAnswer.trim()}>
            {loading ? 'Submitting...' : 'Submit Answer'}
          </button>
        </div>
      )}

      {score !== null && (
        <div>
          <h3>Score: {score}</h3>
          <p>Feedback: {feedback}</p>
        </div>
      )}
    </div>
  );
};

export default App;
